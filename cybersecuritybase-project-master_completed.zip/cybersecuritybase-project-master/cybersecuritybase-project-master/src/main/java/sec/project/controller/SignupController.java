package sec.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;
import sec.project.domain.Signup;
import sec.project.repository.AccountRepository;
import sec.project.repository.SignupRepository;

@Controller
public class SignupController {

    @Autowired
    private SignupRepository signupRepository;

    @Autowired
    private AccountRepository accountRepository;

    @RequestMapping(value = "*", method = RequestMethod.GET)
    public String defaultMapping() {
        return "redirect:/form";
    }

    // This redictor is used to redirect user to the event website
    // if a user is logged into a session, a malicious actor could use the redirector to redirect the user to a malicious site.
    // for example, by getting the user to click a link: http://localhost:8080/redirector?redirurl=malicioussite.com
    // this needs to be removed to fix vulnerability A10
    @RequestMapping("/redirector")
    public RedirectView localRedirect(@RequestParam String redirurl){
        RedirectView redirectView = new RedirectView();
        redirectView.setUrl(redirurl);
        return redirectView;
    }

    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String list(Model model) {

        model.addAttribute("signups", signupRepository.findAll());

        return "form";
    }

    @RequestMapping(value = "/form", method = RequestMethod.POST)
    public String submitForm(Authentication authentication, @RequestParam String name,
                             @RequestParam String address, @RequestParam String url) {

        //String completeUrl = "redirector?redirurl=" + url;
        signupRepository.save(new Signup(name, address, authentication.getName(), url));

        return "done";
    }

}
