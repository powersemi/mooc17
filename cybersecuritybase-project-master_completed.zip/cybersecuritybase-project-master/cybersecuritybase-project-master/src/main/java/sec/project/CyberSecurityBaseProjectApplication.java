package sec.project;

import org.apache.catalina.Context;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatContextCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;

@SpringBootApplication
public class CyberSecurityBaseProjectApplication implements EmbeddedServletContainerCustomizer {

    public static void main(String[] args) throws Throwable {
        SpringApplication.run(CyberSecurityBaseProjectApplication.class);
    }
    @Override
    public void customize(ConfigurableEmbeddedServletContainer cesc) {
        ((TomcatEmbeddedServletContainerFactory) cesc).addContextCustomizers(new TomcatContextCustomizer() {
            @Override
            public void customize(Context cntxt) {
                // some customisation to the security configuration
                cntxt.setUseHttpOnly(false);
                // a longer timeout will ensure that sessions stay valid unnecessary long.
                // This needs to be removed to fix vulnerability A5
                cntxt.setSessionTimeout(999999999);
                // enable cross context
                cntxt.setCrossContext(true);
                //set a shorter session Id which is easy to guess. This needs to be removed to fix vulnerability A2
                cntxt.getManager().getSessionIdGenerator().setSessionIdLength(1);
            }


        });
    }
}

